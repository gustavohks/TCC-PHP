<?php
# CRUD.CLASS.PHP

// CRIAR CLASS
class Crud {

	// config banco
	public $local  ;
	public $user   ;
	public $pass   ;
	public $banco  ;
	public $sql    ;
	public $prepara;
	public $rs     ;
	public $conexao;
	public $data   ;

	public function __construct(){

		// conectar
		$this->conecta('localhost','root','','site00');
	}

	public function __destruct(){
		// rodape
		$this->footer();
	}

	public function conecta($local, $user, $pass, $banco){
		// conectar no banco de dados
		$this->conexao = mysqli_connect($local,$user,$pass,$banco);
	}
	
	public function validar($nome,$email,$senha){
		
		if ((!empty($nome)) && (!empty($email)) && (!empty($senha)) ) {
			$data = 'ok'; 
		}else{
			$data = "erro";
		}
	}
}	
<!DOCTYPE html>
<html>
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="https://fonts.googleapis.com/css?family=Nunito+Sans" rel="stylesheet">

	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/estilos.css">
	<link rel="stylesheet" href="css/media.css">
<style type="text/css">
	.butao{
		margin-left: 3%;
	}
	#porra{
		margin-top: 10%;
	}
	#cadastrar{
		margin-top: 2.9%;
	}
</style>
	<script src="js/jquery-3.3.1.min.js"></script>


	<script type="text/javascript">
		$(document).ready(function(){


	// captura clique no botão
	$("#cadastrar").click(function(){
		// evitar que o form envie os dados

		event.preventDefault();
		var nome = $('#nome').val();
		var email = $('#email').val();
		var senha = $('#senha').val();
		// pede para retornar dados via GET
		$.post("cadastra.php",
		    {
		        nome: nome,
		        email: email,
		        senha: senha
		    },
		     function(data, status){
		    	// se o cadastro funcionou
		    	if (data == 'ok') {
		    		$('#resultado').html('<p class="col-12 alert alert-success"  >Cadastrado com sucesso</p>');
		    		$('#resultado').fadeIn();

		    		// limpar o form
		    		$('#add').trigger('reset');
		    		// colocar cursor no primeiro input
		    		$('#cidade').focus();

		    	} else {
		    	// cadastro deu erro
		    		$('#resultado').html('<p class="col-12 alert alert-danger">Erro de cadastro</p>');
		    		$('#resultado').fadeIn();
		    	}
		    });
		});
    });


</script>

</head>
<body>

	<div class="container-fluid">
		<div class="col-12" id="porra">
			<h2 class="text-center">Cadastrar-se</h2>
			<form id="add" method="POST">
			<div class="row">
				<div class="col-3">&nbsp;</div>
				<h5 style="color: red;">*</h5>
				<label class="col-6">Nome:
					<input type="text" name="nome" id="nome" class="form-control" placeholder="Escreva o nome">
				</label>
			</div>
			<div class="row">
				<div class="col-3">&nbsp;</div>
					<h5 style="color: red;">*</h5>
				<label  class="col-6">Email:
						<input type="email" name="email" id="email" class="form-control" placeholder="Escreva o email">
				</label>
			</div>
			<div class="row">
				<div class="col-3">&nbsp;</div>
					<h5 style="color: red; ">*</h5>
				<label  class="col-6">Senha:
						<input type="password" name="senha" id="senha" class="form-control" placeholder="Senha..">
				</label>
			</div>
			<div class="row">
				<div class="col-5 butao"  >&nbsp;</div>
				<button type="submit" id="cadastrar" nome="cadastrar" class="btn btn-info" >Cadastrar</button>
			</div>
			<div class="row">
				<div id="resultado" class="text-center col-12"></div>
			</div>	
		</div>
		</form>
	</div>



	<!-- Optional JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>

</body>
</html>
<?php
require_once "classes/crud.class.php";
$nome  = strlen($_REQUEST['nome']);
$email = $_REQUEST['email'];
$senha = strlen($_REQUEST['senha']);

$conexao=mysqli_connect('localhost','root','','site00');
$senha_crypt = hash('sha512', $senha);
$sql = "INSERT INTO cadastrados (nome,email, senha) values ('$nome','$email','$senha_crypt')";
$sql2 = "SELECT count(email) from cadastrados WHERE email ="'.$email.';
$verificar = mysqli_query($conexao,$sql2);
$rs = mysqli_fetch_array($verificar);
if ($rs > 0) {
	echo "erro";
}
else{
if(mysqli_query($conexao,$sql)){
	if ( (!empty($nome)) && (!empty($senha))  ) {
		if ($nome >= 3) {
			if(filter_var($email, FILTER_VALIDATE_EMAIL)){
				if ($senha > 6) {
					echo "ok";
				}	

			}
		}
	}
} else {
	echo 'kombi';
}
}
?>
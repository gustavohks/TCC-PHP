<?php
/* Dados do Banco de Dados a conectar */
// $Servidor = 'localhost';
// $nomeBanco = 'cadastrados';
// $Usuario = 'root';
// $Senha = '';
$cadastrados = mysqli_connect('localhost', 'root', '', 'site'); 
?>
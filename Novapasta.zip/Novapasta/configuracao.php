<?php
$cadastrados = mysqli_connect('localhost','root','','site') or die('Erro ao conectar ao banco de dados');
?>
	<!-- Footer -->
  <footer class="page-footer font-small blue pt-4">

    <!-- Footer Links -->
    <div class="container-fluid text-center text-md-left" >

      <!-- Grid row -->
      <div class="row" >

        <!-- Grid column -->
        <div class="col-md-6 mt-md-0 mt-3 text-rodape" >

          <!-- Content -->
          <h5 class="text-uppercase">Redes Sociais</h5>
          <?php 
          require_once "icones.php";
          ?>
          <!-- aqui -->

          <!-- ate aqui -->
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-2 mb-md-0 mb-3 nbsp">&nbsp;</div>
        <div class="col-md-3 mb-md-0 mb-3 link" >

          <!-- Links -->
          <h5 class="text-uppercase">&nbsp;</h5>

          <ul class="list-unstyled">
            <li>
              <a href="index.php">Início</a>
            </li>
            <li>
              <a href="Sobre.php">Sobre nós</a>
            </li>
            <li>
              <a href="Contato.php">Contato</a>
            </li>


          </div>
          <!-- Grid column -->
          

        </div>
        <!-- Footer Links -->

        <!-- Copyright -->
        <div class="col-md-6 footer-copyright text-center py-3" >© 2018 Copyright: Form Buillder JavaScript
        </div>

        </div>
      <!-- Grid row -->
          

        <!-- Copyright -->
    </footer>
    <!-- Footer -->
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
  </div>
</div>
</body>
</html>
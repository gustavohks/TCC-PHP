<?php
require_once"header.php";
require_once"connect.php";
require_once"configuracao.php";
$erro = "0";
$msg_erro = '';
if (isset($_POST['Cadastrar'])) {
	//pegar as informações do formulario cadastro.php
	$prependedtext = $_POST['prependedtext'];
	$nome = $_POST['nome'];
	$cpf = $_POST['cpf'];
	$dtnasc = $_POST['dtnasc'];
	$sexo = $_POST['sexo'];
	$telefone = $_POST['telefone'];
	$celular = $_POST['celular'];
	$password = $_POST['password'];
	$cep = $_POST['cep'];
	$rua = $_POST['rua'];
	$numero = $_POST['numero'];
	$bairro = $_POST['bairro'];
	$cidade = $_POST['cidade'];
	$estado = $_POST['estado'];
	//session VALUES
	echo $sexo;


// 	//validacao de dados
	if  (empty($nome) or empty($cpf) or empty($sexo) or empty($dtnasc) or empty($telefone) or empty($password) or empty($cep) or empty($rua) or empty($bairro) or empty($numero) or empty($cidade) or empty($estado) or empty($prependedtext)) {
		$erro = "1";
		$msg_erro= "Preencha os campos corretamente";
	}else{
		// verificar se o usuário existe no bando de dados
		$sql = "SELECT count(*) FROM cadastrados 
		WHERE email = '".$prependedtext."'";
		
		$prepara = mysqli_query($cadastrados,$sql);
		$total   = mysqli_fetch_array($prepara);
		if ($total['0'] == 0) {
		//criptografar a senha
			$senha_crypt = hash('sha512', $password);

			$sql = "INSERT INTO cadastrados (nome, email, cpf, dtnasc, telefone, celular, sexo, password, cep , rua, numero, bairro, cidade, estado)
			VALUES ('$nome', '$prependedtext', '$cpf', '$dtnasc', '$telefone', '$celular', '$sexo', '$senha_crypt', $cep , '$rua', '$numero', '$bairro', '$cidade', '$estado')";
			if (mysqli_query($cadastrados,$sql)) {
				$registro= mysqli_fetch_array($prepara);	  	
				$total2   = mysqli_num_rows($prepara);
				
				# SESSION
				
				// $_SESSION['autenticado']= 'sim';
				$_SESSION['id'] 		= $registro['id'];
				$_SESSION['nome'] 		= $registro['nome'];
				
				echo ("<SCRIPT LANGUAGE='JavaScript'>
					window.alert('Cadastro concluído com sucesso!')
					window.location.href='index.php';
					</SCRIPT>"
				);

			}
		} elseif ($total['0'] >= 1) {
			//SALVAR OS DADOS NA SESSÃO PARA MOSTRAR NO FORMULÁRIO PARA POSSIVEL CORREÇÃO NO PREENCHIMENTO
			$_SESSION['nome'] =  $nome;
			$_SESSION['cpf'] = $cpf;
			$_SESSION['dtnasc'] = $dtnasc;
			$_SESSION['telefone'] = $telefone;
			$_SESSION['celular'] = $celular;
			$_SESSION['cep'] = $cep;
			$_SESSION['rua'] = $rua;
			$_SESSION['numero'] = $numero;
			$_SESSION['bairro'] = $bairro;
			$_SESSION['cidade'] = $cidade;
			$_SESSION['estado'] = $estado;
			
			echo ("<SCRIPT LANGUAGE='JavaScript'>
					window.alert('Email já utilizado')
					window.location.href='cadastro.php';
					</SCRIPT>"
				);
			
			}
		}
	}

			?>
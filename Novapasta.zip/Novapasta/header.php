<?php 
// inicializar sessao
session_start(); 
require_once"connect.php";
require_once"configuracao.php";

//criação da variavel autenticado na sessão

// LOGOUT
if (isset($_GET['novo'])) {
  session_start();
  $_SESSION['nome'] = '';
  $_SESSION['prependedtext'] = '';
  $_SESSION['cpf'] = '';
  $_SESSION['dtnasc'] = '';
  $_SESSION['sexo'] = '';
  $_SESSION['telefone'] = '';
  $_SESSION['celular'] = '';
  $_SESSION['password'] = '';
  $_SESSION['cep'] = '';
  $_SESSION['rua'] = '';
  $_SESSION['numero'] = '';
  $_SESSION['bairro'] = '';
  $_SESSION['cidade'] = '';
  $_SESSION['estado'] = '';
  header ('Location: cadastro.php');
}
if (isset($_GET['sair'])) {
  session_destroy();
  $_SESSION['nome'] = '';
  $_SESSION['prependedtext'] = '';
  $_SESSION['cpf'] = '';
  $_SESSION['dtnasc'] = '';
  $_SESSION['sexo'] = '';
  $_SESSION['telefone'] = '';
  $_SESSION['celular'] = '';
  $_SESSION['password'] = '';
  $_SESSION['cep'] = '';
  $_SESSION['rua'] = '';
  $_SESSION['numero'] = '';
  $_SESSION['bairro'] = '';
  $_SESSION['cidade'] = '';
  $_SESSION['estado'] = '';
  $_SESSION['autenticado'] = 'deslogado';
  header ('Location: index.php');
}

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Form Buillder</title>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link rel="stylesheet" type="text/css" href="css-custom.css">
<link href="https://fonts.googleapis.com/css?family=Dosis" rel="stylesheet">
<link rel="shortcut icon" href="images/favicon.png" />
</head>
<body>
	<div class="container-fluid">
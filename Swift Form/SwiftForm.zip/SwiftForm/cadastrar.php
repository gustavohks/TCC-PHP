<?php

$nome  = $_REQUEST['nome'];
$email = $_REQUEST['email'];
$senha = $_REQUEST['senha'];

$conexao = mysqli_connect('localhost','root','','swiftform');
$query 	 = "SELECT * FROM usuarios WHERE email='$email'";
$prepara = mysqli_query($conexao, $query);
$rs 	 = mysqli_num_rows($prepara);
$retornoArray = array();                                                                                                        
$retorno= '';

if ($rs > "0" ) {
	// array_push($retorno, "E-mail já está cadastrado<br>");
	$retorno.= 'E-mail já cadastrado.';
	} 

if ((empty($nome)) || (empty($senha))) {
		$retorno.= 'Nome e senha obrigatórios.';
	}

if (strlen($nome) <= 2) {
	$retorno.= 'Nome muito curto.';
	}

if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
$retorno.= 'E-mail inválido.';
  }

 if (strlen($senha) < 6) {
$retorno.= 'Senha deve ter pelo menos 6 caracteres.';
  }

 if (!empty($retorno)) {

print_r($retorno) ;

 } else {

$senha_crypt = hash('sha512', $senha);
$sql = "INSERT INTO usuarios (nome,email, senha) values ('$nome','$email','$senha_crypt')";

if(!mysqli_query($conexao,$sql)){
	$retorno .= 'Erro de SQL <br><br>';
} else {
	echo 'sucesso';
}
 }


 ?>
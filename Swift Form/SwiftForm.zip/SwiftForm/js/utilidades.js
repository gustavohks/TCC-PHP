// var zip = new JSZip();
// var folder = zip.folder("teste");
// // zip.file("Hello.txt", "Hello world\n");
// folder.file("Hello.txt", "Hello world\n");

// jQuery("#blob").on("click", function () {
//     zip.generateAsync({type:"blob"}).then(function (blob) { // 1) generate the zip file
//         saveAs(blob, "hello.zip");                          // 2) trigger the download
//     }, function (err) {
//         jQuery("#blob").text(err);
//     });
// });

// var zip = new JSZip();
// zip.file("Hello.txt", "Hello World\n");
// var img = zip.folder("images");
// img.file("smile.gif", imgData, {base64: true});
// zip.generateAsync({type:"blob"})
// .then(function(content) {
//     // see FileSaver.js
//     saveAs(content, "example.zip");
// });

//download de arquivos
function download(filename, text, charset, format = 'txt') {
    charset = charset ? charset : 'utf-8';
    const dataFormat = this.getDataFormat(format);
    const pom = document.createElement('a');
    pom.setAttribute('href', `data:${dataFormat};charset=${charset},` + encodeURIComponent(text));
    pom.setAttribute('download', filename);

    if (document.createEvent) {
      var event = document.createEvent('MouseEvents');
      event.initEvent('click', true, true);
      pom.dispatchEvent(event);
    } else {
      pom.click();
    }
}

  function getDataFormat(format) {
    if (format == 'txt')
      return 'text/plain';
  }


//script para o funcionamento das tabs
$('.btn').mouseup(function() { this.blur() })
function openTab(evt, nome) {
    var i, tabcontent, tabcontentSource, tabcontentCrud, tabcontentSave,  tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    tabcontentSource = document.getElementsByClassName("tabcontentSource");
    tabcontentCrud = document.getElementsByClassName("tabcontentCrud");
    tabcontentSave = document.getElementsByClassName("tabcontentSave");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    for (i = 0; i < tabcontentSource.length; i++) {
        tabcontentSource[i].style.display = "none";
    }
    for (i = 0; i < tabcontentCrud.length; i++) {
        tabcontentCrud[i].style.display = "none";
    }
    for (i = 0; i < tabcontentSave.length; i++) {
        tabcontentSave[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(nome).style.display = "block";
    evt.currentTarget.className += " active";
}
    document.getElementById("defaultOpen").click();

//mostra os botoes
$(document).ready(function (){
  $('#buttons').show();
    $('.tabEditor').on('click', function(e){
      $('#buttons').show();
    });
});
//permite arrastar os elementos
$("#forma")
  .sortable({
    placeholder: "element-placeholder",
    start: function(e, ui) {
      ui.item.popover('hide');
    }
})
.disableSelection();
//seleciona o primeiro item do modal
$('#modalText').on('shown.bs.modal', function () {
    $('#fetchLabelText').focus();
}) 
// atribui atalhos para salvar e fechar
var KEYCODE_ENTER = 13;
var KEYCODE_ESC = 27;
$(document).keyup(function(e) {
  if (e.keyCode == KEYCODE_ENTER) $('.salvar').click();
  if (e.keyCode == KEYCODE_ESC) $('.fechar').click();
});

//esconde os botões
$(document).ready(function () {
  $(document).on('mouseenter', '.hover', function () {
      $(this).find("#removeText").show();
      $(this).find("#removeNumber").show();
      $(this).find("#removeOptionsBox").show();
      $(this).find("#removeTextTag").show();
      $(this).find("#removeButton").show();
      $(this).find(".removeOptionsBoxInput").show();
      $(this).find(".addOptionsBoxInput").show();
  }).on('mouseleave', '.hover', function () {
      $(this).find("#removeText").hide();
      $(this).find("#removeNumber").hide();
      $(this).find("#removeOptionsBox").hide();
      $(this).find("#removeTextTag").hide();
      $(this).find("#removeButton").hide();
      $(this).find(".removeOptionsBoxInput").hide();
      $(this).find(".addOptionsBoxInput").hide();
  });
});   
  
//apresenta as cores dos botoes
 $(document).on('click', '.btn-xs', function(){
    var style = $(this).val();
    var classe =  'fetchStyleButton'+style+' btn-xs btn btn-'+style+' selected';
    var defaultDanger = 'fetchStyleButtondanger btn-xs btn btn-danger';
    var defaultDefault = 'fetchStyleButtondefault btn-xs btn btn-default';
    var defaultInfo = 'fetchStyleButtoninfo btn-xs btn btn-info';
    var defaultPrimary = 'fetchStyleButtonprimary btn-xs btn btn-primary';
    var defaultWarning = 'fetchStyleButtonwarning btn-xs btn btn-warning';
    var defaultSuccess = 'fetchStyleButtonsuccess btn-xs btn btn-success';
    switch(style) {
    case "default":
      $('#fetchStyleButton'+style).attr('class',classe);
      $('#fetchStyleButtondanger').attr('class',defaultDanger);
      $('#fetchStyleButtoninfo').attr('class',defaultInfo);
      $('#fetchStyleButtonprimary').attr('class',defaultPrimary);
      $('#fetchStyleButtonwarning').attr('class',defaultWarning);
      $('#fetchStyleButtonsuccess').attr('class',defaultSuccess);
        break;
    case "danger":
      $('#fetchStyleButton'+style).attr('class',classe);
      $('#fetchStyleButtondefault').attr('class',defaultDefault);
      $('#fetchStyleButtoninfo').attr('class',defaultInfo);
      $('#fetchStyleButtonprimary').attr('class',defaultPrimary);
      $('#fetchStyleButtonwarning').attr('class',defaultWarning);        
      $('#fetchStyleButtonsuccess').attr('class',defaultSuccess);
        break;
    case "info":
      $('#fetchStyleButton'+style).attr('class',classe);
      $('#fetchStyleButtondanger').attr('class',defaultDanger);
      $('#fetchStyleButtondefault').attr('class',defaultDefault);
      $('#fetchStyleButtonprimary').attr('class',defaultPrimary);
      $('#fetchStyleButtonwarning').attr('class',defaultWarning);        
      $('#fetchStyleButtonsuccess').attr('class',defaultSuccess);
        break;
    case "primary":
      $('#fetchStyleButton'+style).attr('class',classe);
      $('#fetchStyleButtondanger').attr('class',defaultDanger);
      $('#fetchStyleButtoninfo').attr('class',defaultInfo);
      $('#fetchStyleButtondefault').attr('class',defaultDefault);
      $('#fetchStyleButtonwarning').attr('class',defaultWarning);     
      $('#fetchStyleButtonsuccess').attr('class',defaultSuccess);
        break;
    case "warning":
      $('#fetchStyleButton'+style).attr('class',classe);
      $('#fetchStyleButtondanger').attr('class',defaultDanger);
      $('#fetchStyleButtoninfo').attr('class',defaultInfo);
      $('#fetchStyleButtonprimary').attr('class',defaultPrimary);
      $('#fetchStyleButtondefault').attr('class',defaultDefault);        
      $('#fetchStyleButtonsuccess').attr('class',defaultSuccess);
        break;
    case "success":
      $('#fetchStyleButton'+style).attr('class',classe);
      $('#fetchStyleButtondanger').attr('class',defaultDanger);
      $('#fetchStyleButtoninfo').attr('class',defaultInfo);
      $('#fetchStyleButtonprimary').attr('class',defaultPrimary);
      $('#fetchStyleButtonwarning').attr('class',defaultWarning);
      $('#fetchStyleButtondefault').attr('class',defaultDefault);     
        break;
    default:
        
    }
});

 $(document).on('click', '.tabSave', function(){
    $('#buttons').hide();
    $('#saveTitulo').show();
    $('.tabcontentSave').show();
    $('#saveDiv').show();
    $('#savedDiv').hide();
    $('#mostrarDB').hide();
    $('#nextSave').show();
    $('#salvarSistema').hide();
    $('#divSalvarSistema').hide();
    $('#voltarSave').hide();
    $('#resultado').hide();
  });
  //criação do conteudo dos arquivos
  $( "#nextSave" ).click(function() {
    $('#buttons').hide();
    $('#saveTitulo').hide();
    $('#save').hide();
    $('#saveDiv').hide();
    $('#savedDiv').show();
    $('#mostrarDB').hide();
    $('#nextSave').hide();
    $('#salvarSistema').show();
    $('#divSalvarSistema').show();
    $('#voltarSave').show();
    var saved = $('#saveFormDB').val();
    $('#savedFormDB').attr('value', saved);
  });

  $( "#voltarSave" ).click(function() {
    $('#buttons').hide();
    $('#saveTitulo').show();
    $('#save').show();
    $('#saveDiv').show();
    $('#savedDiv').hide();
    $('#mostrarDB').hide();
    $('#nextSave').show();
    $('#salvarSistema').hide();
    $('#divSalvarSistema').hide();
    $('#voltarSave').hide();
    $('#resultado').hide();
  });
  //cadastrar o sistema no banco de dados
  $(document).on('click', '#salvarSistema', function(){
    $('#resultado').html('');
    $('#resultado').fadeOut();
    var html = $('#forma').html();
    var htmlBotoes = $('#buttons').html();
    $('#formulario').attr('value',html);
    $('#botoes').attr('value',htmlBotoes);
    // impede o form de enviara
    event.preventDefault();
    var fk_usuario  = $('#fk_usuario').val();
    var nomeTabela = $('#savedFormDB').val();
    var tabela  = $('#formulario').val();
    var botoes  = $('#botoes').val();
    // console.log(fk_usuario);
    // console.log(nomeTabela);
    // console.log(tabela);
    // console.log(botoes);
    $.post("include/salvarFormulario.php",
    {
      fk_usuario: fk_usuario,
      nomeTabela: nomeTabela,
      tabela: tabela,
      botoes: botoes
    },
    function(data, status){
      // se o cadastro funcionou
      if (data == 'ok') {
        $('#divSalvarSistema').hide();
        $('#resultado').html('<p class="alert alert-success" style="margin-bottom: 19px; border-radius: 6px !important;">Cadastrado com sucesso</p>');
        $('#resultado').fadeIn();
      } else {
      // cadastro deu erro
        $('#divSalvarSistema').hide();
        $('#resultado').html('<p class="alert alert-danger" style="margin-bottom: 19px; border-radius: 6px !important;">Erro de cadastro</p>');
        $('#resultado').fadeIn();
        console.log(data);
      }
    });
  });   
  //editar o sistema 
  $(document).on('click', '#editarSistema', function(){
    $('#resultado').html('');
    $('#resultado').fadeOut();
    var html = $('#forma').html();
    var htmlBotoes = $('#buttons').html();
    $('#formulario').attr('value',html);
    $('#botoes').attr('value',htmlBotoes);
    // impede o form de enviara
    event.preventDefault();

    var nomeTabela = $('#savedFormDB').val();
    var tabela  = $('#formulario').val();
    var botoes  = $('#botoes').val();
    var id  = $('#id').val();
    // console.log(fk_usuario);
    // console.log(nomeTabela);
    // console.log(tabela);
    // console.log(botoes);
    $.post("include/salvarEdicaoFormulario.php",
    {
      id: id,
      nomeTabela: nomeTabela,
      tabela: tabela,
      botoes: botoes
    },
    function(data, status){
      // se o cadastro funcionou
      if (data == 'ok') {
        $('#divEditarSistema').hide();
        $('#resultado').html('<p class="alert alert-success" style="margin-bottom: 19px; border-radius: 6px !important;">Alterado com sucesso</p>');
        $('#resultado').fadeIn();
      } else {
      // cadastro deu erro
        $('#divEditarSistema').hide();
        $('#resultado').html('<p class="alert alert-danger" style="margin-bottom: 19px; border-radius: 6px !important;">Erro de alteração</p>');
        $('#resultado').fadeIn();
        console.log(data);
      }
    });
  }); 
  $( "#nextEdit" ).click(function() {
    $('#buttons').hide();
    $('#saveTitulo').hide();
    $('#save').hide();
    $('#saveDiv').hide();
    $('#savedDiv').show();
    $('#mostrarDB').hide();
    $('#nextEdit').hide();
    $('#editarSistema').show();
    $('#divEditarSistema').show();
    $('#voltarEdit').show();
    var saved = $('#saveFormDB').val();
    $('#savedFormDB').attr('value', saved);
  });

  $( "#voltarEdit" ).click(function() {
    $('#buttons').hide();
    $('#saveTitulo').show();
    $('#save').show();
    $('#saveDiv').show();
    $('#savedDiv').hide();
    $('#mostrarDB').hide();
    $('#nextEdit').show();
    $('#editarSistema').hide();
    $('#divEditarSistema').hide();
    $('#voltarEdit').hide();
    $('#resultado').hide();
  });


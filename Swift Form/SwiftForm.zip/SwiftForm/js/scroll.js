$(document).ready(function(){

var scroll_start = 0;
var startchange = $('#startchange');
var offset = startchange.offset();
if (startchange.length){
    $(document).scroll(function() {
        event.preventDefault();
        scroll_start = $(this).scrollTop();
        if(scroll_start > offset.top) {
            $(".navbar").removeClass("bg-transparent");
        } else {
            $('.navbar').addClass("bg-transparent");
        }
    });
}
});


// $(function() {
//  $('ul.nav navegar').bind('click',function(event){
//     event.preventDefault();
//      var $anchor = $(this);
//      $('html, body').stop().animate({
//          scrollTop: $($anchor.attr('href')).offset().top
//      }, 1000);
//      event.preventDefault();
//  });
// });

$('.navegar').click(function() {
    document.getElementById('conteudo').style.top = '300px';
    var sectionTo = $(this).attr('href');
    $('html, body').animate({
      scrollTop: $(sectionTo).offset().top
    }, 500);
});


// function reset() {
// 	$(".navbar").removeClass("bg-transparent");  
// }

// $(document).keydown(function (e) {
//  var key = e.which;
//  if(key == 116)  // the enter key code
//   {
// 	$(location).attr('href', 'index.php'); 
//   }
// });  3

var iScrollPos = 0;
$(window).scroll(function () {
    var iCurScrollPos = $(this).scrollTop();
    if (iCurScrollPos > iScrollPos) {
        $('.navbar').removeClass("bg-transparent");
    } else if (iCurScrollPos == 0) {
        $('.navbar').addClass("bg-transparent");
        // alert(iCurScrollPos);
    }
    else {
        $('.navbar').removeClass("bg-transparent");
    }
    iScrollPos = iCurScrollPos;
});



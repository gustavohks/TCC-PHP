<?php
  require_once  "include/header.php";
  $nome = $_SESSION['nome'];
// botao de edit da listagem
$id = '';  
if (isset($_POST['editar'])) {
  
  $id = $_POST['id'];

    # code...
    $sql    = "SELECT * FROM formularios WHERE id = " . $id;
    $prepara   = mysqli_query($swiftform, $sql);
    $rs = mysqli_fetch_array($prepara);

    $id            = $rs['id'];
    $nomeTabela    = 'Editar Formulário';
    $tabela        = $rs['tabela'];
    $botoes        = $rs['botoes'];
    $start = '';
    $end = '';
} else {
  $id = '';
  $tabela = '';
  $botoes = '';
  $nomeTabela = 'Nenhum Formulário Selecionado';
  $start = '<div style = "display: none;">';
  $end = "</div>";
}
?>
<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Swift Form</title>

        <!-- <link href="css/bootstrap.min.css" rel="stylesheet"> -->
        <link href="css/bootstrap-responsive.min.css" rel="stylesheet">
        <link href="css/codemirror.css" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <link href="css/form_builder.css" rel="stylesheet">
        <link href="css/css-custom.css" rel="stylesheet">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
        <script src="js/popper.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery-ui.min.js"></script>
        <!-- <link rel='stylesheet' href='http://css-tricks.com/examples/ViewSourceButton/css/style.css' /> -->
        <link rel='stylesheet' href='http://css-tricks.com/examples/ViewSourceButton/css/prettify.css' />
        <script src="js/prettify.js"></script>
        <script type="text/javascript" src="jszip/dist/jszip.js"></script>
        <script type="text/javascript" src="jszip/js/test.js"></script>
        <script type="text/javascript" src="jszip/dist/jszip.min.js"></script>
        <script type="text/javascript" src="jszip/lib/jszip-utils.js"></script>
        <script type="text/javascript" src="jszip/lib/analytics.js"></script>
        <script type="text/javascript" src="jszip/vendor/FileSaver.js"></script>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

  <!-- <link rel="stylesheet" href="AdminLTE-2.4.5/bower_components/bootstrap/dist/css/bootstrap.min.css"> -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="AdminLTE-2.4.5/bower_components/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
  <!-- Ionicons -->
  <link rel="stylesheet" href="AdminLTE-2.4.5/bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="AdminLTE-2.4.5/dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. We have chosen the skin-blue for this starter
        page. However, you can choose any other skin. Make sure you
        apply the skin class to the body tag so the changes take effect. -->
  <link rel="stylesheet" href="AdminLTE-2.4.5/dist/css/skins/skin-blue.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<!--
BODY TAG OPTIONS:
=================
Apply one or more of the following classes to get the
desired effect
|---------------------------------------------------------|
| SKINS         | skin-blue                               |
|               | skin-black                              |
|               | skin-purple                             |
|               | skin-yellow                             |
|               | skin-red                                |
|               | skin-green                              |
|---------------------------------------------------------|
|LAYOUT OPTIONS | fixed                                   |
|               | layout-boxed                            |
|               | layout-top-nav                          |
|               | sidebar-collapse                        |
|               | sidebar-mini                            |
|---------------------------------------------------------|
-->
<body class="hold-transition skin-blue sidebar-mini" style="background: #222d32">
<div class="wrapper">

  <!-- Main Header -->
  <header class="main-header">

    <!-- Logo -->
    <a href="AdminLTE-2.4.5/index2.html" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>SF</b></span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Swift </b>Form</span>
    </a>

    <!-- Header Navbar -->
    <nav class="navbar navbar-static-top" role="navigation"  style="
    padding-left: 0px;">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      <!-- Sidebar user panel (optional) -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="AdminLTE-2.4.5/dist/img/user.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p style="font-size: 13px;">Bem vindo, <br><?php echo $nome?>!</p>
          <!-- Status -->
          
        </div>
      </div>

      

      <!-- Sidebar Menu -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">NAVEGADOR</li>
        <li class="treeview active" >
          <a href="#" style="height: 44px;"><i class="fa fa-edit"></i> <span style="font-size: 14px;">Formulários</span>
            <span class="pull-right-container" style="height: 35px; width: 5px;">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
          </a>
          <ul class="treeview-menu active">
            <li ><a href="criarFormulario.php" style="font-size: 14px;">Criar</a></li>
            <li><a href="listarFormulario.php" style="font-size: 14px;">Listar</a></li>
            <li class="active"><a href="editarFormulario.php" style="font-size: 14px;">Editar</a></li>
          </ul>
        <!-- Optionally, you can add icons to the links -->
        <li><a href="#"><i class="fa fa-gears"></i> <span style="font-size: 14px;">Editar Cadastro</span></a></li>
        <li><a href="?sair"><i class="fas fa-sign-out-alt" name = "sair"></i> <span style="font-size: 14px;">Sair</span></a></li>
        </li>
      </ul>
      <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper" >
    <!-- Content Header (Page header) -->
    <section class="content-header" style="background: #f8f9fa">
 
        <div class="row-fluid" style="overflow: hidden">

            <div class="container-full" >
                <div class="row" >
                    <div class="col-lg-9 col-sm-12">
                        <h2><?php echo $nomeTabela?></h2>
                        <?php echo $start; ?>
                        <hr>
                        <div class="tab">
                                <button class="tablinks tabEditor" id="defaultOpen" onclick="openTab(event, 'content') ">Editor</button>
                                <button class="tablinks tabSource" onclick="openTab(event, 'fonte')">Source</button>
                                <button class="tablinks tabCrud" onclick="openTab(event, 'geraCrud')">CRUD</button>
                                <button class="tablinks tabSave" onclick="openTab(event, 'tabcontentSave')">Save</button>
                                <!-- <li><a href="#source-tab" data-toggle="tab"  id="sourcetab">Source</a></li>                                 -->
                        </div>
                        <!-- Tab content -->

                        <div id="content" class="tabcontent"> 
                             
                            <div class = "row form-horizontal ui-droppable ui-sortable" id="forma">
                            <?php
                            
                              echo $tabela;
                            
                            ?>
                            </div>

                        </div>

                        <div id="fonte" class="tabcontentSource">

                            <div class="source" id="source">

                            </div>
                        </div> 
                        <div id="geraCrud" class="tabcontentCrud" style="display: none">
                            <div id="components-container">
                            <!-- <div class="form-inline" id="inputs" ></div> -->
                            <div class="form-inline" id="crud" ></div>
                            <div id = "configdb" style="padding-top: 20px;padding-left: 20px;"><h3>Configuração do banco de dados</h3></div>
                            <div id = "editdb" class="form-inline" style="padding-left: 20px;padding-right: 20px;padding-top: 20px;">
                              <div class = "col-12" style="padding-bottom: 20px;"><label style="float: left">Banco de Dados: </label><input class="form-control" type="text" name="novoDB" id="novoDB" placeholder="Informar o nome do banco de dados" style="width: 100%;"></div>
                              <div class = "col-12" style="padding-bottom: 20px;"><label style="float: left">Tabela: </label><input class="form-control" type="text" name="novaTabela" id="novaTabela" placeholder="Informar o nome da tabela" style="width: 100%;"></div>
                            </div>                            
                            <div id = "mostrarDB" class="form-inline" style="padding-left: 20px;padding-right: 20px;padding-top: 20px;">
                              <div class = "col-12" style="padding-bottom: 20px;"><label style="float: left">Banco de Dados: </label><input class="form-control" type="text" name="dbSalvo" id="dbSalvo" placeholder="Nome do banco de dados" style="width: 100%;" readonly></div>
                              <div class = "col-12" style="padding-bottom: 10px;"><label style="float: left">Tabela: </label><input class="form-control" type="text" name="tabelaSalvo" id="tabelaSalvo" placeholder="Nome da tabela" style="width: 100%;" readonly></div>
                            </div>
                                      
                              <div id = "divBaixarSistema" style="display: none"><button name="baixarSistema" id = "baixarSistema" class="btn btn-primary btnPrimaryBaixarSistema" >Baixar Sistema</button></div>
                              <hr>
                              <button name="next" id = "next" class="btn btn-success btnSuccess" style="width: 20%; height: 50px; font-size : 16px; margin-bottom: 20px; float:right;">Avançar</button>
                              <button name="voltar" id = "voltar" class="btn btn-danger btnDanger" style="width: 20%; height: 50px; font-size : 16px; display: none; float:right;">Voltar</button>
                            </div>
                            <div class="crud" id="crudAux" style="display: none;"></div>
                        </div>  
                        <div id="tabcontentSave" class="tabcontentSave" style="display: none">
                            <div id="components-container">
                              <!-- <div class="form-inline" id="inputs" ></div> -->
                              <div class="form-inline" id="crud" ></div>
                              <div id = "saveTitulo" style="padding-top: 20px;padding-left: 20px;"><h3>Editar</h3></div>
                              <div id = "saveDiv" class="form-inline" style="padding-left: 20px;padding-right: 20px;padding-top: 20px;">
                                <div class = "col-12" style="padding-bottom: 20px;"><label style="float: left">Nome do formulário: </label><input class="form-control" type="text" name="saveFormDB" id="saveFormDB" placeholder="Defina um nome para o fomulário" value = "<?=$rs['nomeTabela']?>" style="width: 100%;"></div>
                              </div>                            
                              <div id = "savedDiv" class="form-inline" style="padding-left: 20px;padding-right: 20px;padding-top: 20px;">
                                <div class = "col-12" style="padding-bottom: 20px;"><label style="float: left">Nome do formulário: </label><input class="form-control" type="text" name="savedFormDB" id="savedFormDB" placeholder="Nome do formulário" style="width: 100%;" readonly></div>
                              </div>                                  
                                <div id = "divEditarSistema" style="display: none; margin-bottom: 19px;">
                                  <form id="salvar" action="http://localhost/jform/salvar.php" style="border: 0;display: inline">       
                                            <input type="hidden" name="formulario" id="formulario">
                                            <input type="hidden" name="formularioNome" id="formularioNome">
                                            <input type="hidden" name="botoes" id="botoes">
                                            <input type="hidden" name="id" id="id" value = "<?=$id?>">
                                            <button id="editarSistema" class="btn btn-primary btnPrimary" style="width: 100%; height: 50px; font-size : 16px;"> Salvar Sistema</button>
                                  </form>                            
                                </div>
                                <div style="text-align: center;">
                                  <p id="resultado"></p>
                                </div>
                                <hr>
                                <button name="nextEdit" id = "nextEdit" class="btn btn-success btnSuccess" style="width: 20%; height: 50px; font-size : 16px; margin-bottom: 20px; float:right;">Avançar</button>
                                <button name="voltarEdit" id = "voltarEdit" class="btn btn-danger btnDanger" style="width: 20%; height: 50px; font-size : 16px; display: none; float:right;">Voltar</button>
                            </div>
                        </div> 
                        <?php echo $end; ?>                       
                    </div>

                    <div class="col-lg-3 col-sm-12" id = "buttons">
                    <?php

                      echo $botoes;
                    
                    ?>
                    </div>
                </div>
            </div>
        </div>
        </div>
   <!-- Modal -->
  <div class="modal fade" id="modalText" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal text-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Editar</h4>
        </div>
        <div class="modal-body">
          <p>Label:</p>
          <p> <input type="text" name="fetchLabelText" id="fetchLabelText" value=""  style="height: 30px; width:300px"></p>             
          <p>Type:</p>
          <p><select name="fetchTypeText" id="fetchTypeText" style="height: 30px; width:300px">
            <option label="Text Field" value="text">Text Field</option>
            <option label="Password" value="password">Password</option>
            <option label="Email" value="email">Email</option>
            <option label="Color" value="color">Color</option>
          </select></p>             
          <p>Required:</p>
          <p><select name="fetchRequiredText" id="fetchRequiredText" style="height: 30px; width:300px">
            <option label="Sim" value="sim">Sim</option>
            <option label="Nao" value="nao">Não</option>
          </select></p>          
          <p>Placeholder:</p>
          <p> <input type="text" name="fetchPlaceholderText" id="fetchPlaceholderText" value=""  style="height: 30px; width:300px"></p>          
          <p>Name:</p>
          <p> <input type="text" name="fetchNameText" id="fetchNameText" value=""  style="height: 30px; width:300px"></p>          
          <p>Width:</p>
          <p> <input type="number" name="fetchWidthText" id="fetchWidthText" value=""  style="height: 30px; width:300px"></p>             
          <p>Height:</p>
          <p> <input type="number" name="fetchHeightText" id="fetchHeightText" value=""  style="height: 30px; width:300px"></p>            
          <p>Div Size:</p>
          <p> <input type="text" name="fetchDivText" id="fetchDivText" value=""  style="height: 30px; width:300px"></p>                    
          <p>ID:</p>
          <p> <input type="text" name="fetchIdText" id="fetchIdText" value="" ><input type="hidden" id="fetchHiddenText" value=""/></p>
        </div>
        <div class="modal-footer">
          <button type="button" class="salvar btn btn-success btnSuccessModal" data-dismiss="modal" name="salvarText" id="salvarText" value="">Save</button>
          <button type="button" class="fechar btn btn-danger btnDangerModal" data-dismiss="modal" value="">Close</button>
        </div>
      </div>      
    </div>
  </div> 
   <!-- Modal -->
  <div class="modal fade" id="modalNumber" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal Number-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Editar</h4>
        </div>
        <div class="modal-body">
          <p>Label:</p>
          <p> <input type="text" name="fetchLabelNumber" id="fetchLabelNumber" value=""  style="height: 30px; width:300px"></p>                        
          <p>Required:</p>
          <p><select name="fetchRequiredNumber" id="fetchRequiredNumber" style="height: 30px; width:300px">
            <option label="Sim" value="sim">Sim</option>
            <option label="Nao" value="nao">Não</option>
          </select></p>                   
          <p>Name:</p>
          <p> <input type="text" name="fetchNameNumber" id="fetchNameNumber" value=""  style="height: 30px; width:300px"></p>          
          <p>Width:</p>
          <p> <input type="number" name="fetchWidthNumber" id="fetchWidthNumber" value=""  style="height: 30px; width:300px"></p>             
          <p>Height:</p>
          <p> <input type="number" name="fetchHeightNumber" id="fetchHeightNumber" value=""  style="height: 30px; width:300px"></p>               
          <p>Min:</p>
          <p> <input type="number" name="fetchMinNumber" id="fetchMinNumber" value=""  style="height: 30px; width:300px"></p>               
          <p>Max:</p>
          <p> <input type="number" name="fetchMaxNumber" id="fetchMaxNumber" value=""  style="height: 30px; width:300px"></p>               
          <p>Step:</p>
          <p> <input type="number" name="fetchStepNumber" id="fetchStepNumber" value=""  style="height: 30px; width:300px"></p>            
          <p>Div Size:</p>
          <p> <input type="text" name="fetchDivNumber" id="fetchDivNumber" value=""  style="height: 30px; width:300px"></p>                    
          <p>ID:</p>
          <p> <input type="text" name="fetchIdNumber" id="fetchIdNumber" value="" ><input type="hidden" id="fetchHiddenNumber" value=""/></p>
        </div>
        <div class="modal-footer">
          <button type="button" class="salvar btn btn-success btnSuccessModal" data-dismiss="modal" name="salvarNumber" id="salvarNumber" value="">Save</button>
          <button type="button" class="fechar btn btn-danger btnDangerModal" data-dismiss="modal" value="">Close</button>
        </div>
      </div>      
    </div>
  </div> 

  <!-- Modal -->
  <div class="modal fade" id="modalButton" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal Button-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Editar</h4>
        </div>
        <div class="modal-body">          
          <p>Type:</p>
          <p><select name="fetchTypeButton" id="fetchTypeButton" style="height: 30px; width:300px">
            <option label="button" value="button">Button</option>
            <option label="submit" value="submit">Submit</option>
            <option label="reset" value="reset">Reset</option>
          </select></p>           
          <p>Style:</p>
          <p id = "buttonsEstilos">
            <button name="fetchStyleButton" class="fetchStyleButtondefault btn-xs btn btn-default" id="fetchStyleButtondefault" value="default" type="button">Default</button>
            <button name="fetchStyleButton" class="fetchStyleButtondanger btn-xs btn btn-danger"  id="fetchStyleButtondanger" value="danger" type="button">Danger</button>
            <button name="fetchStyleButton" class="fetchStyleButtoninfo btn-xs btn btn-info"    id="fetchStyleButtoninfo" value="info" type="button">Info</button><br>
            <button name="fetchStyleButton" class="fetchStyleButtonprimary btn-xs btn btn-primary" id="fetchStyleButtonprimary" value="primary" type="button">Primary</button>
            <button name="fetchStyleButton" class="fetchStyleButtonwarning btn-xs btn btn-warning" id="fetchStyleButtonwarning" value="warning" type="button">Warning</button>
            <button name="fetchStyleButton" class="fetchStyleButtonsuccess btn-xs btn btn-success" id="fetchStyleButtonsuccess" value="success" type="button">Success</button>
            <!-- <button id="addButton" class="btn btn-primary" style="width: 235px; height: 50px; font-size : 16px;"><i class="fa fa-send-o"></i> Button</button> -->
          </p>         
          <p>Name:</p>
          <p> <input type="text" name="fetchNameButton" id="fetchNameButton" value=""  style="height: 30px; width:300px"></p>          
          <p>Width:</p>
          <p> <input type="text" name="fetchWidthButton" id="fetchWidthButton" value=""  style="height: 30px; width:300px"></p>             
          <p>Height:</p>
          <p> <input type="text" name="fetchHeightButton" id="fetchHeightButton" value=""  style="height: 30px; width:300px"></p>            
          <p>Div Size:</p>
          <p> <input type="text" name="fetchDivButton" id="fetchDivButton" value=""  style="height: 30px; width:300px"></p>                    
          <input type="hidden" id="fetchHiddenButton" value=""/></p>
      </div>
        <div class="modal-footer">
          <button type="button" class="salvar btn btn-success btnSuccessModal" data-dismiss="modal" name="salvarButton" id="salvarButton" value="">Save</button>
          <button type="button" class="fechar btn btn-danger btnDangerModal" data-dismiss="modal" value="">Close</button>
        </div>
      </div>      
    </div>
  </div> 

  <!-- Modal -->
  <div class="modal fade" id="modalTextTag" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal text tag-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Editar</h4>
        </div>
        <div class="modal-body">
          <p>Conteúdo:</p>
          <p> <input type="text" name="fetchContentTextTag" id="fetchContentTextTag" value=""  style="height: 30px; width:300px"></p>             
          <p>Type:</p>
          <p><select name="fetchTypeTextTag" id="fetchTypeTextTag" style="height: 30px; width:300px">
            <option label="Small" value="small">Small</option>
            <option label="Strong" value="strong">Strong</option>
            <option label="Paragraph" value="p">Paragraph</option>
            <option label="h1" value="h1">h1</option>
            <option label="h2" value="h2">h2</option>
            <option label="h3" value="h3">h3</option>
            <option label="h4" value="h4">h4</option>
            <option label="h5" value="h5">h5</option>
            <option label="h6" value="h6">h6</option>
          </select></p>        
          <p>Div Size:</p>
          <p> <input type="text" name="fetchDivTextTag" id="fetchDivTextTag" value=""  style="height: 30px; width:300px"></p>                    
          <p> <input type="hidden" name="fetchIdTextTag" id="fetchIdTextTag" value="" ><input type="hidden" id="fetchHiddenTextTag" value=""/></p>
        </div>
        <div class="modal-footer">
          <button type="button" class="salvar btn btn-success btnSuccessModal" data-dismiss="modal" name="salvarTextTag" id="salvarTextTag" value="">Save</button>
          <button type="button" class="fechar btn btn-danger btnDangerModal" data-dismiss="modal" value="">Close</button>
        </div>
      </div>     
    </div>
  </div> 

  <!-- Modal -->
  <div class="modal fade" id="modalOptionsBox" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal text tag-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Editar</h4>
        </div>
        <div class="modal-body">
          <p>Label:</p> 
          <p> <input type="text" name="fetchLabelOptionsBox" id="fetchLabelOptionsBox" value=""  style="height: 30px; width:300px"></p>

          <p>Name:</p>
          <p> <input type="text" name="fetchNameOptionsBox" id="fetchNameOptionsBox" value=""  style="height: 30px; width:300px"></p>

          <p>Type:</p>
          <p><select name="fetchTypeOptionsBox" id="fetchTypeOptionsBox"" style="height: 30px; width:300px">
            <option label="Checkbox" value="checkbox">Checkbox</option>
            <option label="Radio" value="radio">Radio</option>
          </select></p>              
          <p>Div Size:</p>
          <p> <input type="text" name="fetchDivOptionsBox" id="fetchDivOptionsBox" value=""  style="height: 30px; width:300px"></p>                    
          <input type="hidden" id="fetchHiddenOptionsBox" value=""/>
        </div>
        <div class="modal-footer">
          <button type="button" class="salvar btn btn-success btnSuccessModal" data-dismiss="modal" name="salvarOptionsBox" id="salvarOptionsBox" value="">Save</button>
          <button type="button" class="fechar btn btn-danger btnDangerModal" data-dismiss="modal" value="">Close</button>
        </div>
      </div>     
    </div>
  </div> 
  <!-- Modal -->
  <div class="modal fade" id="modalOptions" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal text tag-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Editar</h4>
        </div>
        <div class="modal-body">
          <p>Legenda:</p>
          <p> <input type="text" name="fetchOption" id="fetchOption" value=""  style="height: 30px; width:300px"><input type="hidden" id="fetchHiddenOption" value=""/></p>          
        <div class="modal-footer">
          <button type="button" class="salvar btn btn-success btnSuccessModal" data-dismiss="modal" name="salvarOption" id="salvarOption" value="">Save</button>
          <button type="button" class="fechar btn btn-danger btnDangerModal" data-dismiss="modal" value="">Close</button>
        </div>
      </div>     
    </div>
  </div> 

</div>
<script src="js/utilidades.js"></script>
<script src="js/geradorCode.js"></script>
<script src="js/formBuilder.js"></script>

    </section>

    <!-- Main content -->
    <section class="content container-fluid" style="min-height: 0px; padding: 30px; background: #f8f9fa" >

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Main Footer -->
  <footer class="main-footer" style="font-size: 12px; background: black">
    <!-- To the right -->
    <!-- Default to the left -->
    <strong >Copyright &copy; 2018 <a href="" >Swift Form</a>.</strong> All rights reserved.
  </footer>
 


<!-- REQUIRED JS SCRIPTS -->

<!-- jQuery 3 -->
<!-- <script src="AdminLTE-2.4.5/bower_components/jquery/dist/jquery.min.js"></script> -->
<!-- Bootstrap 3.3.7 -->
<!-- <script src="AdminLTE-2.4.5/bower_components/bootstrap/dist/js/bootstrap.min.js"></script> -->
<!-- AdminLTE App -->
<script src="AdminLTE-2.4.5/dist/js/adminlte.min.js"></script>

<!-- Optionally, you can add Slimscroll and FastClick plugins.
     Both of these plugins are recommended to enhance the
     user experience. -->
</body>
</html>
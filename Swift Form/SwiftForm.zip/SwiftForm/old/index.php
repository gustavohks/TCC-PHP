<html>
    <head>
        <title>Form Builder</title>
        <!-- <script src="http://code.jquery.com/ui/1.9.2/jquery-ui.js"></script> -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-responsive.min.css" rel="stylesheet">
        <link href="css/codemirror.css" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <link href="css/form_builder.css" rel="stylesheet">
        <link href="css/css-custom.css" rel="stylesheet">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
        <script src="js/popper.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery-ui.min.js"></script>
        <!-- <link rel='stylesheet' href='http://css-tricks.com/examples/ViewSourceButton/css/style.css' /> -->
        <link rel='stylesheet' href='http://css-tricks.com/examples/ViewSourceButton/css/prettify.css' />
        <script src="js/prettify.js"></script>
        <script type="text/javascript" src="jszip/dist/jszip.js"></script>
        <script type="text/javascript" src="jszip/js/test.js"></script>
        <script type="text/javascript" src="jszip/dist/jszip.min.js"></script>
        <script type="text/javascript" src="jszip/lib/jszip-utils.js"></script>
        <script type="text/javascript" src="jszip/lib/analytics.js"></script>
        <script type="text/javascript" src="jszip/vendor/FileSaver.js"></script>
        <style>
          #source {background: rgba(0,0,0,0.8);}
          #crud {background: rgba(0,0,0,0.8);}
          .fonte {margin: 10px; }
          .geraCrud {margin: 10px; }
          .hoverButton {padding-bottom: 5px; padding-top: 5px }
          #content {padding: 40px;padding-top: 20px;}
          #tabcontent { background: rgba(0,0,0,0.8);}
          #source:target { display: block; }
          #source pre { font: 12px/1.6 Monaco, Courier, MonoSpace;  color: white; overflow: auto; }
          #source pre a, #source pre a span { text-decoration: none; color: #00ccff !important; }
          #crud:target { display: block; }
          #crud pre { font: 12px/1.6 Monaco, Courier, MonoSpace;  color: white; overflow: auto; }
          #crud pre a, #crud pre a span { text-decoration: none; color: #00ccff !important; }
          h1, h2, h3, h4, h5, h6, small, strong {display: inline;}

              form * {
              display: block;
              margin: 10px;
          }

        </style>
      
    </head>
    <body>  

<p class="hide" id="result"></p>
        <div class="row-fluid" style="overflow: hidden">

            <div class="container">
                <div class="row">
                    <div class="col-9">
                        <h1>Swift Form</h1>
                        <hr>
                        <div class="tab">
                                <button class="tablinks tabEditor" id="defaultOpen" onclick="openTab(event, 'content') ">Editor</button>
                                <button class="tablinks tabSource" onclick="openTab(event, 'fonte')">Source</button>
                                <button class="tablinks tabCrud" onclick="openTab(event, 'geraCrud')">CRUD</button>
                                <!-- <li><a href="#source-tab" data-toggle="tab"  id="sourcetab">Source</a></li>                                 -->
                        </div>
                        <!-- Tab content -->

                        <div id="content" class="tabcontent"> 
                             
                            <div class = "row form-horizontal ui-droppable ui-sortable" id="forma"><div class = "col-12"></div></div>

                        </div>

                        <div id="fonte" class="tabcontentSource">

                            <div class="source" id="source">

                            </div>
                        </div> 
                        <div id="geraCrud" class="tabcontentCrud" style="display: none">
                            <div id="components-container">
                            <!-- <div class="form-inline" id="inputs" ></div> -->
                            <div class="form-inline" id="crud" ></div>
                            <div id = "configdb" style="padding-top: 20px;padding-left: 20px;"><h3>Configuração do banco de dados</h3></div>
                            <div id = "editdb" class="form-inline" style="padding-left: 20px;padding-right: 20px;padding-top: 20px;">
                              <div class = "col-12" style="padding-bottom: 20px;"><label style="float: left">Banco de Dados: </label><input class="form-control" type="text" name="novoDB" id="novoDB" placeholder="Informar o nome do banco de dados" style="width: 100%;"></div>
                              <div class = "col-12" style="padding-bottom: 20px;"><label style="float: left">Tabela: </label><input class="form-control" type="text" name="novaTabela" id="novaTabela" placeholder="Informar o nome da tabela" style="width: 100%;"></div>
                            </div>                            
                            <div id = "mostrarDB" class="form-inline" style="padding-left: 20px;padding-right: 20px;padding-top: 20px;">
                              <div class = "col-12" style="padding-bottom: 20px;"><label style="float: left">Banco de Dados: </label><input class="form-control" type="text" name="dbSalvo" id="dbSalvo" placeholder="Nome do banco de dados" style="width: 100%;" readonly></div>
                              <div class = "col-12" style="padding-bottom: 10px;"><label style="float: left">Tabela: </label><input class="form-control" type="text" name="tabelaSalvo" id="tabelaSalvo" placeholder="Nome da tabela" style="width: 100%;" readonly></div>
                            </div>
<!--                               <div class="control-group component"> 
                                    <button name="database.sql" id = "sql" onclick="download(this.name, this.value)" value = "" class="btn btn-primary" style="width: 100%; height: 50px; font-size : 16px;">Baixar SQL</button>
                              </div>
                              <div class="control-group component">        
                                    <button name="index.php" id = "indexphp" onclick="download(this.name, this.value)" value = "" class="btn btn-primary" style="width: 100%; height: 50px; font-size : 16px;">Baixar index.php</button>
                              </div>
                              <div class="control-group component">        
                                    <button name="crud.class.php" id = "classesphp" onclick="download(this.name, this.value)" value = "" class="btn btn-primary" style="width: 100%; height: 50px; font-size : 16px;">Baixar crud.class.php</button>
                              </div> -->
                                      
                              <div id = "divBaixarSistema" style="display: none"><button name="baixarSistema" id = "baixarSistema" class="btn btn-primary" style="width: 100%; height: 50px; font-size : 16px; margin-bottom: 4px; margin-top: 9px; display: none;">Baixar Sistema</button></div>
                              <hr>
                              <button name="next" id = "next" class="btn btn-success" style="width: 20%; height: 50px; font-size : 16px; margin-bottom: 20px; float:right;">Avançar</button>
                              <button name="voltar" id = "voltar" class="btn btn-danger" style="width: 20%; height: 50px; font-size : 16px; display: none; float:right;">Voltar</button>
                            </div>
                            <div class="crud" id="crudAux" style="display: none;"></div>
                        </div>                        
                    </div>

                    <div class="col-md-3 col-sm-12" id = "botoes">
                        <h1>Botões</h1>
                        <hr>
                        <div id="components-container" >
                            <div class="control-group component">
                                <button id="addTextTag" class="btn btn-primary" style="width: 235px; height: 50px; font-size : 16px;"><i class="fa fa-code" aria-hidden="true"></i> Text Tag</button>
                            </div>
                            <div class="control-group component" data-type="text">
                                <button id="addText" class="btn btn-primary" style="width: 235px; height: 50px; font-size : 16px;"><i class="fa fa-indent" aria-hidden="true"></i> Text</button>
                            </div>
                            <div class="control-group component" data-type="text">
                                <button id="addNumber" class="btn btn-primary" style="width: 235px; height: 50px; font-size : 16px;"><i class="fa fa-calculator" aria-hidden="true"></i> Number</button>
                            </div>
                            <div class="control-group component">
                                <button id="addOptionsBox" class="btn btn-primary" style="width: 235px; height: 50px; font-size : 16px;"><i class="fa fa-check-square-o" aria-hidden="true"></i> Option Box</button>
                            </div>
                            <div class="control-group component">
                                    <button id="addButton" class="btn btn-primary" style="width: 235px; height: 50px; font-size : 16px;"><i class="fa fa-send-o"></i> Button</button>
                            </div>
                            <hr>  
                              <div class="control-group component">
                            <form id="salvar" action="http://localhost/jform/salvar.php" style="border: 0;margin: 0;display: inline">       
                                      <input type="hidden" name="tabela" id="tabela">
                                      <button id="salvarSistema" class="btn btn-success" style="width: 235px; height: 50px; font-size : 16px; margin:0"> Salvar Sistema</button>
                            </form>                            
                              </div>
                            <div class="form-actions component" data-type="submit">
                                <input class="btn btn-danger"  type="button" value="Refresh Page" onClick="window.location.reload()" style="width: 235px; height: 50px; font-size : 16px;">
                                <!-- <input class="btn btn-info"  type="button" id="copyHTML" value="Copy HTML" style="width: 100%; height: 33px; font-size : 16px; margin-top: 10px;"> -->
                                <!-- data-toggle="modal" data-target="#modalCopyHTML" -->
                            </div>
                           
                            <div class="control-group component">
                              <p id="resultado"></p>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
   <!-- Modal -->
  <div class="modal fade" id="modalText" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal text-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Editar</h4>
        </div>
        <div class="modal-body">
          <p>Label:</p>
          <p> <input type="text" name="fetchLabelText" id="fetchLabelText" value=""  style="height: 30px; width:300px"></p>             
          <p>Type:</p>
          <p><select name="fetchTypeText" id="fetchTypeText" style="height: 30px; width:300px">
            <option label="Text Field" value="text">Text Field</option>
            <option label="Password" value="password">Password</option>
            <option label="Email" value="email">Email</option>
            <option label="Color" value="color">Color</option>
          </select></p>             
          <p>Required:</p>
          <p><select name="fetchRequiredText" id="fetchRequiredText" style="height: 30px; width:300px">
            <option label="Sim" value="sim">Sim</option>
            <option label="Nao" value="nao">Não</option>
          </select></p>          
          <p>Placeholder:</p>
          <p> <input type="text" name="fetchPlaceholderText" id="fetchPlaceholderText" value=""  style="height: 30px; width:300px"></p>          
          <p>Name:</p>
          <p> <input type="text" name="fetchNameText" id="fetchNameText" value=""  style="height: 30px; width:300px"></p>          
          <p>Width:</p>
          <p> <input type="number" name="fetchWidthText" id="fetchWidthText" value=""  style="height: 30px; width:300px"></p>             
          <p>Height:</p>
          <p> <input type="number" name="fetchHeightText" id="fetchHeightText" value=""  style="height: 30px; width:300px"></p>            
          <p>Div Size:</p>
          <p> <input type="text" name="fetchDivText" id="fetchDivText" value=""  style="height: 30px; width:300px"></p>                    
          <p>ID:</p>
          <p> <input type="text" name="fetchIdText" id="fetchIdText" value="" ><input type="hidden" id="fetchHiddenText" value=""/></p>
        </div>
        <div class="modal-footer">
          <button type="button" class="salvar btn btn-success" data-dismiss="modal" name="salvarText" id="salvarText" value="">Save</button>
          <button type="button" class="fechar btn btn-danger" data-dismiss="modal" value="">Close</button>
        </div>
      </div>      
    </div>
  </div> 
   <!-- Modal -->
  <div class="modal fade" id="modalNumber" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal Number-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Editar</h4>
        </div>
        <div class="modal-body">
          <p>Label:</p>
          <p> <input type="text" name="fetchLabelNumber" id="fetchLabelNumber" value=""  style="height: 30px; width:300px"></p>             
          <p>Type:</p>
          <p><select name="fetchTypeNumber" id="fetchTypeNumber" style="height: 30px; width:300px">
            <option label="Number" value="number">Number Field</option>
            <option label="Range" value="range">Range</option>
          </select></p>             
          <p>Required:</p>
          <p><select name="fetchRequiredNumber" id="fetchRequiredNumber" style="height: 30px; width:300px">
            <option label="Sim" value="sim">Sim</option>
            <option label="Nao" value="nao">Não</option>
          </select></p>                   
          <p>Name:</p>
          <p> <input type="text" name="fetchNameNumber" id="fetchNameNumber" value=""  style="height: 30px; width:300px"></p>          
          <p>Width:</p>
          <p> <input type="number" name="fetchWidthNumber" id="fetchWidthNumber" value=""  style="height: 30px; width:300px"></p>             
          <p>Height:</p>
          <p> <input type="number" name="fetchHeightNumber" id="fetchHeightNumber" value=""  style="height: 30px; width:300px"></p>               
          <p>Min:</p>
          <p> <input type="number" name="fetchMinNumber" id="fetchMinNumber" value=""  style="height: 30px; width:300px"></p>               
          <p>Max:</p>
          <p> <input type="number" name="fetchMaxNumber" id="fetchMaxNumber" value=""  style="height: 30px; width:300px"></p>               
          <p>Step:</p>
          <p> <input type="number" name="fetchStepNumber" id="fetchStepNumber" value=""  style="height: 30px; width:300px"></p>            
          <p>Div Size:</p>
          <p> <input type="text" name="fetchDivNumber" id="fetchDivNumber" value=""  style="height: 30px; width:300px"></p>                    
          <p>ID:</p>
          <p> <input type="text" name="fetchIdNumber" id="fetchIdNumber" value="" ><input type="hidden" id="fetchHiddenNumber" value=""/></p>
        </div>
        <div class="modal-footer">
          <button type="button" class="salvar btn btn-success" data-dismiss="modal" name="salvarNumber" id="salvarNumber" value="">Save</button>
          <button type="button" class="fechar btn btn-danger" data-dismiss="modal" value="">Close</button>
        </div>
      </div>      
    </div>
  </div> 

  <!-- Modal -->
  <div class="modal fade" id="modalButton" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal Button-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Editar</h4>
        </div>
        <div class="modal-body">          
          <p>Type:</p>
          <p><select name="fetchTypeButton" id="fetchTypeButton" style="height: 30px; width:300px">
            <option label="button" value="button">Button</option>
            <option label="submit" value="submit">Submit</option>
            <option label="reset" value="reset">Reset</option>
          </select></p>           
          <p>Style:</p>
          <p id = "butoesEstilos">
            <button name="fetchStyleButton" class="fetchStyleButtonDefault btn-xs btn btn-default" id="fetchStyleButtonDefault" value="Default" type="button">Default</button>
            <button name="fetchStyleButton" class="fetchStyleButtonDanger btn-xs btn btn-danger"  id="fetchStyleButtonDanger" value="Danger" type="button">Danger</button>
            <button name="fetchStyleButton" class="fetchStyleButtonInfo btn-xs btn btn-info"    id="fetchStyleButtonInfo" value="Info" type="button">Info</button>
            <button name="fetchStyleButton" class="fetchStyleButtonPrimary btn-xs btn btn-primary" id="fetchStyleButtonPrimary" value="Primary" type="button">Primary</button>
            <button name="fetchStyleButton" class="fetchStyleButtonWarning btn-xs btn btn-warning" id="fetchStyleButtonWarning" value="Warning" type="button">Warning</button>
            <button name="fetchStyleButton" class="fetchStyleButtonSuccess btn-xs btn btn-success" id="fetchStyleButtonSuccess" value="Success" type="button">Success</button>
            <!-- <button id="addButton" class="btn btn-primary" style="width: 235px; height: 50px; font-size : 16px;"><i class="fa fa-send-o"></i> Button</button> -->
          </p>         
          <p>Name:</p>
          <p> <input type="text" name="fetchNameButton" id="fetchNameButton" value=""  style="height: 30px; width:300px"></p>          
          <p>Width:</p>
          <p> <input type="text" name="fetchWidthButton" id="fetchWidthButton" value=""  style="height: 30px; width:300px"></p>             
          <p>Height:</p>
          <p> <input type="text" name="fetchHeightButton" id="fetchHeightButton" value=""  style="height: 30px; width:300px"></p>            
          <p>Div Size:</p>
          <p> <input type="text" name="fetchDivButton" id="fetchDivButton" value=""  style="height: 30px; width:300px"></p>                    
          <input type="hidden" id="fetchHiddenButton" value=""/></p>
      </div>
        <div class="modal-footer">
          <button type="button" class="salvar btn btn-success" data-dismiss="modal" name="salvarButton" id="salvarButton" value="">Save</button>
          <button type="button" class="fechar btn btn-danger" data-dismiss="modal" value="">Close</button>
        </div>
      </div>      
    </div>
  </div> 

  <!-- Modal -->
  <div class="modal fade" id="modalTextTag" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal text tag-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Editar</h4>
        </div>
        <div class="modal-body">
          <p>Conteúdo:</p>
          <p> <input type="text" name="fetchContentTextTag" id="fetchContentTextTag" value=""  style="height: 30px; width:300px"></p>             
          <p>Type:</p>
          <p><select name="fetchTypeTextTag" id="fetchTypeTextTag" style="height: 30px; width:300px">
            <option label="Small" value="small">Small</option>
            <option label="Strong" value="strong">Strong</option>
            <option label="Paragraph" value="p">Paragraph</option>
            <option label="h1" value="h1">h1</option>
            <option label="h2" value="h2">h2</option>
            <option label="h3" value="h3">h3</option>
            <option label="h4" value="h4">h4</option>
            <option label="h5" value="h5">h5</option>
            <option label="h6" value="h6">h6</option>
          </select></p>        
          <p>Div Size:</p>
          <p> <input type="text" name="fetchDivTextTag" id="fetchDivTextTag" value=""  style="height: 30px; width:300px"></p>                    
          <p> <input type="hidden" name="fetchIdTextTag" id="fetchIdTextTag" value="" ><input type="hidden" id="fetchHiddenTextTag" value=""/></p>
        </div>
        <div class="modal-footer">
          <button type="button" class="salvar btn btn-success" data-dismiss="modal" name="salvarTextTag" id="salvarTextTag" value="">Save</button>
          <button type="button" class="fechar btn btn-danger" data-dismiss="modal" value="">Close</button>
        </div>
      </div>     
    </div>
  </div> 

  <!-- Modal -->
  <div class="modal fade" id="modalOptionsBox" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal text tag-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Editar</h4>
        </div>
        <div class="modal-body">
          <p>Label:</p> 
          <p> <input type="text" name="fetchLabelOptionsBox" id="fetchLabelOptionsBox" value=""  style="height: 30px; width:300px"></p>

          <p>Name:</p>
          <p> <input type="text" name="fetchNameOptionsBox" id="fetchNameOptionsBox" value=""  style="height: 30px; width:300px"></p>

          <p>Type:</p>
          <p><select name="fetchTypeOptionsBox" id="fetchTypeOptionsBox"" style="height: 30px; width:300px">
            <option label="Checkbox" value="checkbox">Checkbox</option>
            <option label="Radio" value="radio">Radio</option>
          </select></p>              
          <p>Div Size:</p>
          <p> <input type="text" name="fetchDivOptionsBox" id="fetchDivOptionsBox" value=""  style="height: 30px; width:300px"></p>                    
          <input type="hidden" id="fetchHiddenOptionsBox" value=""/>
        </div>
        <div class="modal-footer">
          <button type="button" class="salvar btn btn-success" data-dismiss="modal" name="salvarOptionsBox" id="salvarOptionsBox" value="">Save</button>
          <button type="button" class="fechar btn btn-danger" data-dismiss="modal" value="">Close</button>
        </div>
      </div>     
    </div>
  </div> 
  <!-- Modal -->
  <div class="modal fade" id="modalOptions" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal text tag-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Editar</h4>
        </div>
        <div class="modal-body">
          <p>Legenda:</p>
          <p> <input type="text" name="fetchOption" id="fetchOption" value=""  style="height: 30px; width:300px"><input type="hidden" id="fetchHiddenOption" value=""/></p>          
        <div class="modal-footer">
          <button type="button" class="salvar btn btn-success" data-dismiss="modal" name="salvarOption" id="salvarOption" value="">Save</button>
          <button type="button" class="fechar btn btn-danger" data-dismiss="modal" value="">Close</button>
        </div>
      </div>     
    </div>
  </div> 

</div>
<script src="js/utilidades.js"></script>
<script src="js/geradorCode.js"></script>
<script src="js/formBuilder.js"></script>
<?php 
  
?>
    </body>
</html>

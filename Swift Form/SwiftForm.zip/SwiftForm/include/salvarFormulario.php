<?php 
// require_once "header.php";

$fk_usuario = $_REQUEST['fk_usuario'];
$nomeTabela = $_REQUEST['nomeTabela'];
$tabela = $_REQUEST['tabela'];
$botoes = $_REQUEST['botoes'];

$conexao=mysqli_connect('localhost','root','','swiftform');
$sql = "INSERT INTO formularios (fk_usuarios, nomeTabela, tabela, botoes) values ('$fk_usuario', '$nomeTabela', '$tabela', '$botoes')";

if(mysqli_query($conexao,$sql)){
	echo 'ok';
} else {
	echo 'kombi';
	echo $sql;
}


?>
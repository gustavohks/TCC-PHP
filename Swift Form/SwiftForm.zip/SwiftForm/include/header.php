<?php
// inicializar sessao
session_start();

require_once "include/config.php";
require_once "include/connect.php";

// LOGOUT
if (isset($_GET['sair'])) {
	// destruir sessao ativa
	session_destroy();
	// criar sessao nova
	session_start();
	// redirecionar pra pagina de login
	header("Location: index.php");
}

// VERIFICAR SE NÃO ESTA NA PÁGINA LOGIN
	// retornar endereço da página
	$url 		= $_SERVER['PHP_SELF'];
	// transforma o endereço em vetor, usando / como
	// criterio de separação
	$vetor_url  = explode('/', $url);
	// pegar ultimo dado do vetor
	$pagina 	= end($vetor_url);

	// verifica se esta em qualquer página que não
	// seja a login.php
	if ($pagina != 'index.php') {
		// verifica se NAO esta autenticado
		if (!isset($_SESSION['autenticado'])) {
			// redireciona para login.php
			header("Location: index.php");
		}
	}

// receber dados do formulário de LOGIN
if (isset($_POST['email']) && isset($_POST['senha']))  {

	// receber dados
	$email = $_POST['email'];
	$senha = $_POST['senha'];

	// verificar se os campos foram preenchidos
	if ( !empty($email) && !empty($senha) ) {

		// verificar se o usuário existe no bando de dados
		$sql = "SELECT count(*) FROM usuarios 
				WHERE email = '".$email."'";
		$prepara = mysqli_query($swiftform,$sql);
		$total   = mysqli_fetch_array($prepara);

		// EMAIL verificar se houve retorno
		if ($total['count(*)'] > 0) {

			// criptografar senha
			$senha_crypt = hash('sha512', $senha);

			$sql = "SELECT id, email, nome FROM usuarios WHERE 
							email = '".$email."' AND
							senha = '".$senha_crypt."'";

			$prepara = mysqli_query($swiftform,$sql);
			$registro= mysqli_fetch_array($prepara);	  	
			$total   = mysqli_num_rows($prepara);
			// SENHA | usuário e senha conferem
			echo $senha . '<br>';		
			echo $senha_crypt . '<br>';		
			if ($total > 0) {

				# SESSION
				// autenticar / criar sessao
				$_SESSION['autenticado']= 'sim';
				$_SESSION['id'] 		= $registro['id'];
				$_SESSION['nome'] 		= $registro['nome'];
				// redirect pra index.php
				header("Location: criarFormulario.php");
			} else {
				echo 'dados nao conferem';
			}

		} else {
			echo 'email nao existe';
		}	  
	}
}

?>



<?php
// DADOS DE CONEXAO
define('LOCAL', 'localhost');
define('USER' , 'root');
define('PASS' , '');
define('DB'   , 'swiftform');




?>
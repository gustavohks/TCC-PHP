<?php 
// require_once "header.php";

	$nomeTabela = $_REQUEST['nomeTabela'];
	$tabela = $_REQUEST['tabela'];
	$botoes = $_REQUEST['botoes'];
	$id = $_REQUEST['id'];


	$conexao=mysqli_connect('localhost','root','','swiftform');
	$sql = "UPDATE formularios SET 
							nomeTabela = '$nomeTabela', 
							tabela = '$tabela', 
							botoes = '$botoes' 
					WHERE id = " . $id;

	if(mysqli_query($conexao,$sql)){
		echo 'ok';
	} else {
		echo 'kombi';
		echo $sql;
	}

?>
<?php
// local
// nome de usuário
// senha do banco de dados
// qual banco de dados
$swiftform = mysqli_connect(LOCAL,USER,PASS,DB) or die("Erro banco!");

?>
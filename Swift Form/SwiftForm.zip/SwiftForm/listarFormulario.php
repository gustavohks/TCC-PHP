<?php
  require_once  "include/header.php";
  $nome = $_SESSION['nome'];

if (isset($_POST['excluir'])) {

  $id = $_POST['id'];

  $sql = "DELETE FROM formularios WHERE id = " . $id;
  if (mysqli_query($swiftform, $sql)) {
    $aviso = '<p class="alert alert-success" style="border-radius: 6px !important;">Excluido com sucesso!</p>'; 
  } else {
    $aviso = '<p class="alert alert-danger" style="margin-bottom: 19px; border-radius: 6px !important;">Erro no banco de dados!</p>'; 
  }
}

?>

<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Swift Form</title>

        <!-- <link href="css/bootstrap.min.css" rel="stylesheet"> -->
        <link href="css/bootstrap-responsive.min.css" rel="stylesheet">
        <link href="css/codemirror.css" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <link href="css/form_builder.css" rel="stylesheet">
        <link href="css/css-custom.css" rel="stylesheet">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
        <script src="js/popper.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery-ui.min.js"></script>
        <!-- <link rel='stylesheet' href='http://css-tricks.com/examples/ViewSourceButton/css/style.css' /> -->
        <link rel='stylesheet' href='http://css-tricks.com/examples/ViewSourceButton/css/prettify.css' />
        <script src="js/prettify.js"></script>
        <script type="text/javascript" src="jszip/dist/jszip.js"></script>
        <script type="text/javascript" src="jszip/js/test.js"></script>
        <script type="text/javascript" src="jszip/dist/jszip.min.js"></script>
        <script type="text/javascript" src="jszip/lib/jszip-utils.js"></script>
        <script type="text/javascript" src="jszip/lib/analytics.js"></script>
        <script type="text/javascript" src="jszip/vendor/FileSaver.js"></script>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

  <!-- <link rel="stylesheet" href="AdminLTE-2.4.5/bower_components/bootstrap/dist/css/bootstrap.min.css"> -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="AdminLTE-2.4.5/bower_components/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
  <!-- Ionicons -->
  <link rel="stylesheet" href="AdminLTE-2.4.5/bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="AdminLTE-2.4.5/dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. We have chosen the skin-blue for this starter
        page. However, you can choose any other skin. Make sure you
        apply the skin class to the body tag so the changes take effect. -->
  <link rel="stylesheet" href="AdminLTE-2.4.5/dist/css/skins/skin-blue.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<!--
BODY TAG OPTIONS:
=================
Apply one or more of the following classes to get the
desired effect
|---------------------------------------------------------|
| SKINS         | skin-blue                               |
|               | skin-black                              |
|               | skin-purple                             |
|               | skin-yellow                             |
|               | skin-red                                |
|               | skin-green                              |
|---------------------------------------------------------|
|LAYOUT OPTIONS | fixed                                   |
|               | layout-boxed                            |
|               | layout-top-nav                          |
|               | sidebar-collapse                        |
|               | sidebar-mini                            |
|---------------------------------------------------------|
-->
<body class="hold-transition skin-blue sidebar-mini" style="background: #222d32">
<div class="wrapper">

  <!-- Main Header -->
  <header class="main-header">

    <!-- Logo -->
    <a href="AdminLTE-2.4.5/index2.html" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>SF</b></span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Swift </b>Form</span>
    </a>

    <!-- Header Navbar -->
    <nav class="navbar navbar-static-top" role="navigation"  style="
    padding-left: 0px;">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      <!-- Sidebar user panel (optional) -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="AdminLTE-2.4.5/dist/img/user.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p style="font-size: 13px;">Bem vindo, <br><?php echo $nome?>!</p>
          <!-- Status -->
          
        </div>
      </div>

      

      <!-- Sidebar Menu -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">NAVEGADOR</li>
        <li class="treeview active" >
          <a href="#" style="height: 44px;"><i class="fa fa-edit"></i> <span style="font-size: 14px;">Formulários</span>
            <span class="pull-right-container" style="height: 35px; width: 5px;">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
          </a>
          <ul class="treeview-menu active">
            <li><a href="criarFormulario.php" style="font-size: 14px;">Criar</a></li>
            <li class="active"><a href="listarFormulario.php" style="font-size: 14px;">Listar</a></li>
            <li><a href="editarFormulario.php" style="font-size: 14px;">Editar</a></li>
          </ul>
        <!-- Optionally, you can add icons to the links -->
        <li><a href="#"><i class="fa fa-gears"></i> <span style="font-size: 14px;">Editar Cadastro</span></a></li>
        <li><a href="?sair"><i class="fas fa-sign-out-alt" name = "sair"></i> <span style="font-size: 14px;">Sair</span></a></li>
        </li>
      </ul>
      <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper" >
    <!-- Content Header (Page header) -->
    <section class="content-header" style="background: #f8f9fa; margin: 0px;">
  
      <nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #367fa9;" >
        <a class="navbar-brand" href="">CRUD</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item">
          <a class="nav-link" href="">Listagem</a>
            </li>
            <li class="nav-item">
          <a class="nav-link" href="criarFormulario.php">Cadastrar</a>
            </li>
          </ul>
      </div>
      </nav>
      <table class="table table-striped table-bordered table-hover table-sm">
        <thead>
          <tr>
            <th scope="col-4" style="width: 20px">#</th>
            <th scope="col-4" style="width: 500px;text-align: left !important;">Nome do Formulário</th>
            <th scope="col-4" style="width: 50px !important">Editar</th>
            <th scope="col-4" style="width: 20px">Deletar</th>
          </tr>
        </thead>
        <tbody>

        <?php
        
        $sql       = "SELECT nomeTabela, tabela, botoes, usuarios.id AS idUsuario, formularios.id AS idFormulario FROM formularios LEFT JOIN usuarios ON fk_usuarios = usuarios.id";
        $prepara   = mysqli_query($swiftform, $sql);
        $i = 0;
        while ($rs = mysqli_fetch_array($prepara)) {
          if ($rs['idUsuario'] == $_SESSION['id']) {
             $i++;
        ?>
          <tr>
            <td scope="row">
              <?php echo $i?>
            </td>
            <td style="text-align: left !important;"><?=$rs['nomeTabela']?></td>
            <td scope="row">
          <form method="POST" action="editarFormulario.php">
            <input type="hidden" name="id" value="<?=$rs['idFormulario']?>">
            <button type="submit" name="editar" value="Editar" class="btn btn-primary centerButton" style="width: 35px; height: 35px;"><i class="fas fa-pencil-alt"></i></button>
          </form>
            </td>
            <td scope="row">
          <form method="POST">
            <input type="hidden" name="id" value="<?=$rs['idFormulario']?>">
            <button type="submit" name="excluir" value="X" class="btn btn-danger centerButton" style="width: 35px; height: 35px;"><i class="far fa-trash-alt"></i></button>
          </form>
            </td>
          </tr>

        <?php
           } 

        }

        ?>
        </tbody>

      </table>
      <?php 
      if ($i==0) {
        echo '<label>Showing 0 to '.$i.'  of '.$i.'  entries.</label>';
      }  else {
        echo '<label>Showing 1 to '.$i.'  of '.$i.'  entries.</label>';
      }
      ?>
      
      <?php 

      ?>
  </div> 

</div>
<script src="js/utilidades.js"></script>
<script src="js/geradorCode.js"></script>
<script src="js/formBuilder.js"></script>

    </section>

    <!-- Main content -->

    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Main Footer -->
  <footer class="main-footer" style="font-size: 12px; background: black">
    <!-- To the right -->
    <!-- Default to the left -->
    <strong >Copyright &copy; 2018 <a href="" >Swift Form</a>.</strong> All rights reserved.
  </footer>
 


<!-- REQUIRED JS SCRIPTS -->

<!-- jQuery 3 -->
<!-- <script src="AdminLTE-2.4.5/bower_components/jquery/dist/jquery.min.js"></script> -->
<!-- Bootstrap 3.3.7 -->
<!-- <script src="AdminLTE-2.4.5/bower_components/bootstrap/dist/js/bootstrap.min.js"></script> -->
<!-- AdminLTE App -->
<script src="AdminLTE-2.4.5/dist/js/adminlte.min.js"></script>

<!-- Optionally, you can add Slimscroll and FastClick plugins.
     Both of these plugins are recommended to enhance the
     user experience. -->
</body>
</html>
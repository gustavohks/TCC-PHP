<?php
// inicializar sessao

require_once "include/config.php";
require_once "include/connect.php";
require_once  "include/header.php";

if(!(isset($_SESSION['nome'])))
{
	$nome = '';
	$display = '';
	$sair = '';
	$displayLog = '';
	$footer = 'page-footer font-small pt-4';
	$displayOut = 'display: none;';
} else {
	$nome = $_SESSION['nome'];
	$displayLog = 'display: none;';
	$footer = 'page-footer font-small';
	$sair = 'Sair';
}


// if(session_id() == '101tovi95r25drac52l9ahm7nm') {
// } else {
// }
?>

<!DOCTYPE html>
<html>
<head>
	<title>Swift Form - Index</title>
	<link rel="stylesheet" type="text/css" href="css/estiloIndex.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/login/util.css">
	<link rel="stylesheet" type="text/css" href="css/login/mainIndex.css">
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
	<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
</head>
<body id = "topo">
	<div class="container-fluid">
		<div class="row sticky-top">
			    <nav class="navbar navbar-expand-lg navbar-dark bg-dark bg-transparent">			        
			        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggler" aria-controls="navbarToggler" aria-expanded="false" aria-label="Toggle navigation" style="margin-left: 1vh !important;">
			            <span class="navbar-toggler-icon"></span>
			        </button>
			        	<a class="navbar-brand" href="" >Swift Form</a>
		        <div class="collapse navbar-collapse " id="navbarToggler">
		            <ul class="navbar-nav mr-auto">
						<li class="nav-item">
						<a class="nav-link active" href="index.php">Home <span class="sr-only">(current)</span></a>
						</li>
						<li class="nav-item">
						<a class="nav-link" href="cadastro.php" style="<?php echo $displayLog?>">Cadastro</a>
						</li>
		            </ul>
		            <ul class="navbar-nav mr-auto">
		                <li class="nav-item">
		                </li>
		            </ul>
		            <ul class="navbar-nav">
						<li class="nav-item">
						    <a class="nav-link navegar" href="#index">Início</a>
						</li>
						<li class="nav-item">
						    <a class="nav-link navegar" href="#conteudo">Sobre</a>
						</li>
						<li class="nav-item">
						    <a class="nav-link navegar" style="color: #0099ff;" href="?sair"><?php echo $sair ?></a>
						</li>
		            </ul>
		        </div>
		    </nav>
		</div>
		
		<div id="startchange"></div>
		<div class="row">
			<div class="col-12 index" id = "index">
				<div class = "col-12" style="max-height: 400px;min-height: 400px;"></div>
				<div class="row header">
				   <div class="col-xl-1 d-xl-block d-none d-lg-none" style=" color: white">&nbsp</div>
					<div class="col-xl-4 col-lg-12 text-xl-left text-md-center text-sm-center text-center-xs titulo">
						<img  data-tilt src="images/logo12.png" class = "logo">
						<p class="textoHeader"">
							<br>Levamos praticidade ao seu trabalho. 
							Gerencie telas com o simples clique do mouse.
						</p>
					</div>
					<div class="col-xl-3 d-xl-block d-none d-lg-none" >&nbsp</div>
					<div class="col-xl-3 col-lg-12" style=" color: white; height:auto !important; margin:0 auto !important; <?php echo $displayLog?>">		
							<div class = "loginBox" style="margin:0 auto !important;">
								<p class = "login100-form-title">Bem vindo!</p>
						  		<form class  = "formLogin" method="POST" action="#" >
<!-- 			  						<div class="col-12 form-group">
			    						<p style="text-align: left !important;">
			    						  <label for="exampleInputEmail1" >Email:</label>
									      <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Digite seu Email...">
			    						</p>
			                        </div> -->
									<div class="wrap-input100 validate-input" data-validate = "Campo inválido. Mínimo 2 caracteres.">
										<input class="input100" type="email" name="email" id="email" placeholder="Digite seu Email...">
										<span class="focus-input100"></span>
										<span class="symbol-input100">
											<i class="fa fa-envelope" aria-hidden="true"></i>
										</span>
									</div>									
									<div class="wrap-input100 validate-input" data-validate = "Campo inválido. Mínimo 2 caracteres.">
										<input class="input100" type="password" name="senha" id="senha" placeholder="Digite sua senha...">
										<span class="focus-input100"></span>
										<span class="symbol-input100">
											<i class="fa fa-lock" aria-hidden="true"></i>
										</span>
									</div>
<!-- 									<div class="col-12 form-group">
										<p style="text-align: left !important;">							
			 					          <label for="exampleInputPassword1">Senha:</label>
									      <input type="password" name="senha" class="form-control" id="exampleInputPassword1" placeholder="Digite sua senha...">
										</p>
								    </div> -->
								   
<!-- 								    <center>
								      <button type="submit" class="btn btn-primary" style="width: 150px">Entrar</button>
								      <br>
									<i>Não possui cadastro? <br>
										<a href="cadastro.php">Inscreva-se</a>
									</i>
									</center> -->

									<div class="container-login100-form-btn">
										<button type="submit" id="entrar" name="entrar" class="login100-form-btn">
											Entrar
										</button>
									</div>
									<div class="text-center p-t-12">
										<span class="txt1">
											Não possui cadastro?
										</span>
										<a class="txt2" href="cadastro.php">
											Inscreva-se.
										</a>
									</div>

								</form>
							</div>
					</div>
					<div class="col-xl-3 col-lg-12" style=" color: white; height:auto !important; margin:0 auto !important; <?php echo $displayOut ?>">		
							<div class = "logado" style="margin:0 auto !important;">
								<p style="padding-top: 20px;">
								  <h3 style="">Bem vindo, <?php echo "<div>" . $nome . "!</div>"; ?></h3>
								  <a style="">Para ir ao seu painel de usuário, <br><a href="criarFormulario.php">clique aqui.</a></a>
								</p>

							</div>
					</div>
				   <div class="col-xl-1 d-xl-block d-none d-lg-none" style=" color: white">&nbsp</div>
				</div>		
			</div>
		</div>
		<div ></div>
		<div class="row conteudo" id = "conteudo">
            <div class="content-lg container">
                <div class="masonry-grid row" style="position: relative;">
                    <div data-aos-duration="1000" data-aos="fade-right" class="col-md-12" style="text-align: center;">
            			<h3 data-aos-duration="1000" data-aos="fade-right" >Sobre o nosso produto</h3>
            			<hr>
            			<br>                     
                    </div>
                    <div data-aos-duration="1000" data-aos="flip-left" class="masonry-grid-item col-md-4 sm-margin-b-30 blocos" >
								<i class="fas fa-user-cog icon"></i>
								<h4>Prático</h4>
								<p class="texto">
										Todas as suas ações são feitas de forma simples e prática pelo mouse. Crie, mova e edite elementos de acordo com a sua necessidade ou gosto...
								</p> 
                    </div>
                    <div data-aos-duration="1000" data-aos="flip-left" class="masonry-grid-item col-xs-12 col-sm-6 col-md-4 blocos" >
								<i class="far fa-thumbs-up icon"></i>
								<h4>Dinâmico</h4>
								<p class="texto">
										Baixe o sistema de cadastro da tela criada, ou se desejar, o seu código fonte. Cadastre suas telas no site para futuras modificações. Poupe o seu trabalho!
									</p>  
    				</div>
                    <div data-aos-duration="1000" data-aos="flip-right" class="col-xs-12 col-sm-6 col-md-4 sm-margin-b-30 blocos">
								<i class="fas fa-users icon"></i>
								<h4>Ergônomico</h4>
								<p class="texto">
						 				Com um design agradável e intuitivo, tenha à sua disposição diversas ferramentas sem precisar navegar entre vários menus. Qualquer pessoa pode usar... 
								</p>                       
                    </div>
                </div>
            </div>
        </div>
		<div class="row conteudoBottom" id = "conteudoBottom">
            <div class="content-lg container">
                <div class="masonry-grid row" style="position: relative;">
                    <div class="col-md-12" style="text-align: center;">
                    			<h3 data-aos-duration="1000" data-aos="fade-right" >Gerencie suas Telas</h3>
                    			<hr data-aos-duration="1000" data-aos="fade-right">
                    			<br>   

                    </div>
                    <div data-aos-duration="1000" data-aos="flip-left" class="col-md-4 blocos">
                    			<h4>Design</h4><br>
								<img src="images/img3.png" width="80%" style="max-width:225px">                        
                    </div>
                    <div data-aos-duration="1000" data-aos="flip-left" class="col-md-4 blocos">
                				<h4>Cadastro</h4><br>	
								<img src="images/img1.png" width="65%" style="max-width:200px">                    
                    </div>
                    <div data-aos-duration="1000" data-aos="flip-left" class="col-md-4 blocos">
                    			<h4>Download</h4><br>
								<img src="images/img2.png" width="90%" style="max-width:275px">                    
                    </div>
                </div>
            </div>	
        </div>
	</div>

	<footer class = "<?php echo $footer?>" style="background-color: #212529">
	    <!-- Footer Elements -->
	    <div class="container" style="<?php echo $displayLog ?>">

	      <!-- Call to action -->
	      <ul class="list-unstyled list-inline text-center py-2" style="padding-bottom: 30px !important; ">
	        <li class="list-inline-item">
	          <h5 class="mb-1">Registre de graça.</h5>
	        </li>
	        <li class="list-inline-item">
	          <a href="cadastro.php" class="btn btn-outline-white btn-rounded">Sign up!</a>
	        </li>
	      </ul>
	      <!-- Call to action -->

	    </div>
	    <!-- Footer Elements -->

	    <!-- Copyright -->
	    <div class="footer-copyright text-center py-3" style="font-size: 14px">© 2018 Copyright:
	      <a href="http://localhost/swiftform/index.php"> Swift Form</a>
	    </div>
	    <!-- Copyright -->

	  </footer>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="js/popper.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/scroll.js"></script>
		<!-- <script src="vendor/tilt/tilt.jquery.min.js"></script> -->
		<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
		<script>
  			AOS.init();
		</script>
</body>
</html>
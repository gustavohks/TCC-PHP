<?php

session_start();
require_once "include/config.php";
require_once "include/connect.php";

if(isset($_SESSION['nome'])) {

	header("Location: http://localhost/swiftform/index.php");

}
?>

<!DOCTYPE html>
<html>
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Swift Form - Cadastro</title>	
	<link rel="stylesheet" type="text/css" href="css/estiloCadastro.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="icon" type="image/png" href="images/favicon.ico"/>
	<link rel="stylesheet" type="text/css" href="css/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/login/util.css">
	<link rel="stylesheet" type="text/css" href="css/login/main.css">
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script type="text/javascript">
	$(document).ready(function(){


	// captura clique no botão
	$("#cadastrar").click(function(){
		// evitar que o form envie os dados

		event.preventDefault();
		var nome 	= $('#nome').val();
		var email 	= $('#email').val();
		var senha 	= $('#senha').val();
		// pede para retornar dados via GET
		$.post("cadastrar.php",
		{
			nome: nome,
			email: email,
			senha: senha
		},
		function(data, status){

		    	// se o cadastro funcionou
		    	if (data == 'sucesso') {

		    		// $('#loginDiv').attr("class", "display_none");
		    		$('#add').addClass("display_none");
		    		$('.divSucesso').removeClass("display_none");
					window.setTimeout(function() {
					    window.location.href = 'http://localhost/swiftform/index.php';
					}, 3000);
		    		// limpar o form
		    		$('#add').trigger('reset');
		    		

		    	} else {		
		    		// if (data = "E-mail já está cadastrado<br>") {}
		    		var msg = data;
					// var a = 'how are you';
					if (msg.indexOf('E-mail já cadastrado.') > -1) {
		    			$('.valEmail').attr('data-validate','E-mail já cadastrado.');
		    			$('.valEmail').addClass('alert-validate');
					} else {
						$('.valEmail').attr('data-validate','Favor inserir um email válido: ex@abc.xyz');
					}

		    		// $('#resultado').fadeIn();	
		    	}

		    });
	});
});

</script>
</head>

<body>
	<div class="container-fluid">
		
		<div class="row sticky-top">
		    <nav class="navbar navbar-expand-lg navbar-dark bg-dark bg-transparent">
		        
		        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggler" aria-controls="navbarToggler" aria-expanded="false" aria-label="Toggle navigation" style="margin-left: 1vh !important;">
		            <span class="navbar-toggler-icon"></span>
		        </button>
		        	<a class="navbar-brand" href="" >Swift Form</a>
		        <div class="collapse navbar-collapse " id="navbarToggler" style="margin-right: 100px !important">
		            <ul class="navbar-nav mr-auto">
						<li class="nav-item">
						<a class="nav-link " href="index.php">Home</a>
						</li>
						<li class="nav-item">
						<a class="nav-link active" href="cadastro.php">Cadastro<span class="sr-only">(current)</span></a>
						</li>
		            </ul>
		            <ul class="navbar-nav mr-auto">
		                <li class="nav-item">
		                </li>
		            </ul>
		        </div>
		    </nav>
		</div>
		<div  id="startchange" style="display: none; padding-top: -200px"></div>

		<div class="row">

			<div class="limiter col-12 LoginForm" id="LoginForm">
				
				<div class="container-login100">
					<div class="wrap-login100">
						<div class="login100-pic js-tilt" data-tilt style="padding-top: 70px">
							<img src="images/logo13.png" alt="IMG" width="300px">
						</div>
						<div class="divSucesso display_none" style="width: 250px;">
								<div id="sucesso" class="sucesso" style="padding-top: 90px; padding-right: 20px; width: 300px" ><a style="font-size: 18px;">Cadastrado com sucesso! <br> Você será redirecionado em um momento.</a></div>
						</div>
						<form class="login100-form validate-form" id="add" method="POST" style="">
							<span class="login100-form-title">
								Criar Conta
							</span>

							<div class="wrap-input100 validate-input" data-validate = "Campo inválido. Mínimo 2 caracteres.">
								<input class="input100" type="text" name="nome" id="nome" placeholder="Nome">
								<span class="focus-input100"></span>
								<span class="symbol-input100">
									<i class="fas fa-user"></i>
								</span>
							</div>

							<div class="wrap-input100 validate-input valEmail" data-validate = "Favor inserir um email válido: ex@abc.xyz">
								<input class="input100" type="email" name="email" id="email" placeholder="Email">
								<span class="focus-input100"></span>
								<span class="symbol-input100">
									<i class="fa fa-envelope" aria-hidden="true"></i>
								</span>
							</div>


							<div class="wrap-input100 validate-input" data-validate = "Campo inválido. Mínimo 6 digitos.">
								<input class="input100" type="password" id="senha" name="senha" placeholder="Password">
								<span class="focus-input100"></span>
								<span class="symbol-input100">
									<i class="fa fa-lock" aria-hidden="true"></i>
								</span>
							</div>
							
							<div class="container-login100-form-btn">
								<button type="submit" id="cadastrar" name="cadastrar" class="login100-form-btn">
									Cadastrar
								</button>
							</div>

							<div class="text-center p-t-12">
								<span class="txt1">
									Já está registrado?
								</span>
								<a class="txt2" href="index.php">
									Clique aqui.
								</a>
							</div>
						</form>
					</div>
				</div>
			</div>	
		</div>
<!-- 		<div class="row divResultado">
				<div id="resultado" class="col-12 resultado" ></div>
		</div> -->
	</div>	

	<footer class="font-small">
		<div class="footer-copyright text-center py-3" style="font-size: 14px">© 2018 Copyright:
		  <a href="http://localhost/swiftform/index.php"> Swift Form</a>
		</div>
	</footer>

	
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/scroll.js"></script>
<script src="vendor/select2/select2.min.js"></script>
<script src="vendor/tilt/tilt.jquery.min.js"></script>
<script >
	$('.js-tilt').tilt({
		scale: 1.1
	})
</script>
<script src="js/main.js"></script>
</body>
</html>

<!-- 		<div class="row">
			<div class="col-12 cadastro" id = "cadastro">
				<div class = "col-12" style="max-height: 400px;min-height: 400px;"></div>
				<div class="col-lg-12" style=" color: white; height:auto !important; margin:0 auto !important;">		
						<div class = "registerBox" id="loginDiv" style="margin:0 auto !important;">								
								<p id = "title">
								  <h3 style="">Criar conta</h3>
								</p>
						  		<form id="add" method="POST">
			  						<div class="col-12 form-group">
			    						<p style="text-align: left !important;">
			    						  <label for="nome" >Nome:</label>
									      <input type="text" name="nome" class="form-control" id="nome" aria-describedby="nomeHelp" placeholder="Nome completo..." >
			    						</p>
			                        </div>
			  						<div class="col-12 form-group">
			    						<p style="text-align: left !important;">
			    						  <label for="email" >Email:</label>
									      <input type="email" class="form-control" id="email" name="email" placeholder="exemplo@exemplo.com">
			    						</p>
			                        </div>
									<div class="col-12 form-group">
										<p style="text-align: left !important;">							
			 					          <label for="password">Senha:</label>
									      <input type="password" class="form-control" id="senha" name="senha" placeholder="Mínimo 6 caracteres...">
										</p>
								    </div>
								    <center>
										<button type="submit" id="cadastrar" name="cadastrar" class="col-6 btn btn-info">
											Cadastrar-se<i style="padding-left: 15px;" class="far fa-check-circle"></i>
										</button>
								      <br>
									</center>
								<div class="row divResultado">
										<div id="resultado" class="col-12 resultado" ></div>
								</div>
								</form>
						</div>
						<div class="row divSucesso">
								<div id="sucesso" class="col-2 sucesso" ></div>
						</div>
				</div>
			</div>
		</div> -->